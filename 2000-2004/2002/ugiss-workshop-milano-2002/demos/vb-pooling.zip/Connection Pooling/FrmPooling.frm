VERSION 5.00
Begin VB.Form FrmPooling 
   Caption         =   "Test Connection Pooling"
   ClientHeight    =   1980
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   1980
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command2 
      Caption         =   "No Pooling"
      Height          =   615
      Left            =   720
      TabIndex        =   1
      Top             =   960
      Width           =   3255
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Pooling"
      Height          =   615
      Left            =   720
      TabIndex        =   0
      Top             =   240
      Width           =   3255
   End
End
Attribute VB_Name = "FrmPooling"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim AdoCnn As Connection

Private Sub Command1_Click()
   Dim AdoRs  As Recordset
   
   Screen.MousePointer = vbHourglass
   
   
   
   Set AdoRs = New Recordset
   
   With AdoCnn
        .Open
   End With
   
   With AdoRs
        .ActiveConnection = AdoCnn
        .Open "SELECT CompanyName FROM Customers"
   End With
   
   
   AdoRs.Close
   AdoCnn.Close
   
   Set AdoRs = Nothing
   
   
   Screen.MousePointer = vbNormal
End Sub

Private Sub Command2_Click()

   Dim AdoRs         As Recordset
   Dim AdoCnnNoPool  As Connection
   
   Screen.MousePointer = vbHourglass
   
   Set AdoCnnNoPool = New Connection
   
   Set AdoRs = New Recordset
   
   With AdoCnnNoPool
        .ConnectionString = "Provider=SQLOLEDB.1;Password=test;Persist Security Info=True;User ID=test;Initial Catalog=Northwind;Data Source=NOONE2\SQL2000SP;OLE DB Services=-2"
        .Open
   End With
   
   With AdoRs
        .ActiveConnection = AdoCnnNoPool
        .Open "SELECT CompanyName FROM Customers"
   End With
   
   
   AdoRs.Close
   AdoCnnNoPool.Close
   
   Set AdoCnnNoPool = Nothing
   Set AdoRs = Nothing
   
   
   Screen.MousePointer = vbNormal
End Sub

Private Sub Form_Load()

  Set AdoCnn = New Connection
  
  With AdoCnn
      .ConnectionString = "Provider=SQLOLEDB.1;Password=test;Persist Security Info=True;User ID=test;Initial Catalog=Northwind;Data Source=NOONE2\SQL2000SP"
      .ConnectionTimeout = 3
  End With

End Sub
