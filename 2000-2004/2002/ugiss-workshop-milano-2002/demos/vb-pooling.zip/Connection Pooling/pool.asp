<%

	dim ObjCom
	dim ObjRs
	
	set ObjCom = server.CreateObject("UgissConnPooling.clsUser")
	
	
	
	ObjCom.CallRecordSet
	
	response.Write ("Ok")
	
	
	set ObjCom = NOthing 
	

%>