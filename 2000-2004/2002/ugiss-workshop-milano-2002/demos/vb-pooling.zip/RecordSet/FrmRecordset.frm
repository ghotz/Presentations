VERSION 5.00
Begin VB.Form FrmRs 
   Caption         =   "Test RecordSet"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7800
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   7800
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton CmdScorri 
      Caption         =   "Scorri RecordSet"
      Height          =   495
      Left            =   2760
      TabIndex        =   9
      Top             =   1680
      Width           =   2775
   End
   Begin VB.ComboBox CboLock 
      Height          =   315
      ItemData        =   "FrmRecordset.frx":0000
      Left            =   4440
      List            =   "FrmRecordset.frx":0010
      Style           =   2  'Dropdown List
      TabIndex        =   4
      Top             =   360
      Width           =   3375
   End
   Begin VB.ComboBox CboPosition 
      Height          =   315
      ItemData        =   "FrmRecordset.frx":0060
      Left            =   2760
      List            =   "FrmRecordset.frx":006A
      Style           =   2  'Dropdown List
      TabIndex        =   2
      Top             =   360
      Width           =   1575
   End
   Begin VB.ComboBox CboRecordSet 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      ItemData        =   "FrmRecordset.frx":007E
      Left            =   120
      List            =   "FrmRecordset.frx":008E
      Style           =   2  'Dropdown List
      TabIndex        =   0
      Top             =   360
      Width           =   2535
   End
   Begin VB.CommandButton CmdCrea 
      Caption         =   "Crea RecordSet"
      Height          =   495
      Left            =   2760
      TabIndex        =   6
      Top             =   960
      Width           =   2775
   End
   Begin VB.Label lbl 
      Caption         =   "Tipo Lock Creato"
      Height          =   255
      Index           =   10
      Left            =   120
      TabIndex        =   15
      Top             =   1560
      Width           =   1815
   End
   Begin VB.Label lbl 
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   9
      Left            =   120
      TabIndex        =   14
      Top             =   1800
      Width           =   2535
   End
   Begin VB.Label lbl 
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   8
      Left            =   120
      TabIndex        =   13
      Top             =   1080
      Width           =   2535
   End
   Begin VB.Label lbl 
      Caption         =   "Tipo Cursore Creato"
      Height          =   255
      Index           =   7
      Left            =   120
      TabIndex        =   12
      Top             =   840
      Width           =   1815
   End
   Begin VB.Label lbl 
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   6
      Left            =   5760
      TabIndex        =   11
      Top             =   1800
      Width           =   1815
   End
   Begin VB.Label lbl 
      Caption         =   "Tempo Move"
      Height          =   255
      Index           =   5
      Left            =   5760
      TabIndex        =   10
      Top             =   1560
      Width           =   1815
   End
   Begin VB.Label lbl 
      Caption         =   "Tempo Open"
      Height          =   255
      Index           =   4
      Left            =   5760
      TabIndex        =   8
      Top             =   840
      Width           =   1815
   End
   Begin VB.Label lbl 
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   5760
      TabIndex        =   7
      Top             =   1080
      Width           =   1815
   End
   Begin VB.Label lbl 
      Caption         =   "Tipo Lock"
      Height          =   255
      Index           =   2
      Left            =   4440
      TabIndex        =   5
      Top             =   120
      Width           =   1575
   End
   Begin VB.Label lbl 
      Caption         =   "Posizione"
      Height          =   255
      Index           =   1
      Left            =   2760
      TabIndex        =   3
      Top             =   120
      Width           =   1575
   End
   Begin VB.Label lbl 
      Caption         =   "Tipo Cursore"
      Height          =   255
      Index           =   0
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Width           =   2535
   End
End
Attribute VB_Name = "FrmRs"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim AdoCnn As Connection
Dim AdoRs  As Recordset

Const STRSQL As String = "Select CustomerId,CompanyName from Customers"

Private Sub CmdCrea_Click()

    SetupRecordSet

End Sub

Private Sub CmdScorri_Click()

    Dim dTime As Double
    
    Me.MousePointer = vbHourglass
    
    dTime = Timer
    
    With AdoRs
         Do While Not .EOF
            .MoveNext
         Loop
    End With
    
    lbl(6).Caption = FormatNumber(Timer - dTime, 2, vbTrue)
    
    
    Me.MousePointer = vbNormal

End Sub

Private Sub CmdTipoCursore_Click()

    'adOpenDynamic = 2
    'adOpenForwardOnly = 0
    'adOpenKeyset = 1
    'adOpenStatic = 3



    With AdoRs
    
        If .State = adStateOpen Then
           Select Case .CursorType
           
                  Case adOpenDynamic
                  
                       MsgBox "adOpenDynamic"
                       
                  Case adOpenForwardOnly
                  
                       MsgBox "adOpenForwardOnly"
                                       
                  Case adOpenKeyset
                  
                        MsgBox "adOpenKeyset"
                                    
                  Case adOpenStatic
                        
                        MsgBox "adOpenStatic"
            End Select
        Else
            MsgBox "RecordSet chiuso !!!"
        End If
        
    End With

End Sub

Private Sub Form_Load()

  Set AdoCnn = New Connection
  AdoCnn.ConnectionString = "Provider=SQLOLEDB.1;Password=test;Persist Security Info=True;User ID=test;Initial Catalog=Northwind;Data Source=NOONE2\SQL2000SP"
  
  CboRecordSet.ListIndex = 0
  CboPosition.ListIndex = 0
  CboLock.ListIndex = 0

End Sub

Private Sub Form_Unload(Cancel As Integer)

    If AdoCnn.State = adStateOpen Then
       AdoCnn.Close
    End If
    
    Set AdoRs = Nothing
    Set AdoCnn = Nothing
    
    
End Sub

Private Sub Label1_Click()

End Sub

Private Sub SetupRecordSet()

    Dim dTime As Double


    Me.MousePointer = vbHourglass

    Set AdoRs = New Recordset
    
    With AdoRs
          'Setto CursorLocation
          
          Select Case CboPosition.Text
                 Case "Client"
                      .CursorLocation = adUseClient
                 Case "Server"
                      .CursorLocation = adUseServer
          End Select
          
          'Setto CursorType
          
          Select Case CboRecordSet.Text
                 Case "Forward Only"
                       .CursorType = adOpenForwardOnly
                 Case "Static Cursor"
                       .CursorType = adOpenStatic
                 Case "KeySet Cursor"
                       .CursorType = adOpenKeyset
                 Case "Dynamic Cursor"
                        .CursorType = adOpenDynamic
          End Select
          
          'Setto LockType
          
          Select Case CboLock.Text
                 Case "AdLockReadOnly"
                       .LockType = adLockReadOnly
                 Case "AdLockOptimistic"
                       .LockType = adLockOptimistic
                 Case "AdLockPessimistic"
                       .LockType = adLockPessimistic
                 Case "AdLockBatchOptimistic"
                       .LockType = adLockBatchOptimistic
          End Select
          
          'Verifico Connessione
          
          Debug.Print "1)" & Timer
          
          dTime = Timer
          
          If AdoCnn.State = adStateClosed Then
             AdoCnn.Open
          End If
          
          'Apro RecordSet
          
          .Open STRSQL, AdoCnn
          
          
          Debug.Print "2)" & Timer
          
          lbl(3).Caption = FormatNumber(Timer - dTime, 2, vbTrue)
          
          'Aggiorni Tipo Lock
          
          lbl(9).Caption = .LockType
          
          Select Case .LockType

                  Case adLockReadOnly

                       lbl(9).Caption = "adLockReadOnly"

                  Case adLockOptimistic

                       lbl(9).Caption = "adLockOptimistic"

                  Case adLockPessimistic

                        lbl(9).Caption = "adLockPessimistic"

                  Case adLockBatchOptimistic

                        lbl(9).Caption = "adLockBatchOptimistic"
          End Select


          'Aggiorni Tipo Cursore
          
          Select Case .CursorType
           
                  Case adOpenDynamic
                  
                       lbl(8).Caption = "adOpenDynamic"
                       
                  Case adOpenForwardOnly
                  
                       lbl(8).Caption = "adOpenForwardOnly"
                                       
                  Case adOpenKeyset
                  
                        lbl(8).Caption = "adOpenKeyset"
                                    
                  Case adOpenStatic
                        
                        lbl(8).Caption = "adOpenStatic"
          End Select
          
       End With
          
          
       Me.MousePointer = vbNormal

End Sub

