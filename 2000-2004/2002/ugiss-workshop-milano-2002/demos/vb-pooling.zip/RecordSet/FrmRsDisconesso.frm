VERSION 5.00
Begin VB.Form FrmRsDisconesso 
   Caption         =   "Recordset disconesso"
   ClientHeight    =   3585
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   3585
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame 
      Height          =   2295
      Left            =   120
      TabIndex        =   1
      Top             =   840
      Visible         =   0   'False
      Width           =   3375
      Begin VB.CommandButton CmdSalvaServer 
         Caption         =   "Salva Server"
         Height          =   375
         Left            =   1080
         TabIndex        =   7
         Top             =   1440
         Width           =   1215
      End
      Begin VB.CommandButton CmdSalva 
         Caption         =   "Salva Locale"
         Height          =   375
         Left            =   1080
         TabIndex        =   6
         Top             =   960
         Width           =   1215
      End
      Begin VB.CommandButton CmdIndietro 
         Caption         =   "<<"
         Height          =   375
         Left            =   120
         TabIndex        =   5
         Top             =   960
         Width           =   855
      End
      Begin VB.CommandButton CmdAvanti 
         Caption         =   ">>"
         Height          =   375
         Left            =   2400
         TabIndex        =   4
         Top             =   960
         Width           =   855
      End
      Begin VB.TextBox TxtCompany 
         Height          =   300
         Left            =   120
         TabIndex        =   3
         Top             =   600
         Width           =   1695
      End
      Begin VB.TextBox TtxId 
         Height          =   300
         Left            =   120
         Locked          =   -1  'True
         TabIndex        =   2
         TabStop         =   0   'False
         Top             =   240
         Width           =   1215
      End
   End
   Begin VB.CommandButton CmdCreaRs 
      Caption         =   "Crea Recordset"
      Height          =   495
      Left            =   120
      TabIndex        =   0
      Top             =   240
      Width           =   1815
   End
End
Attribute VB_Name = "FrmRsDisconesso"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim AdoCnn As Connection
Dim AdoRs  As Recordset

Const STRSQL As String = "Select CustomerId,CompanyName from Customers"

Private Sub CmdAvanti_Click()

    With AdoRs
         If Not .EOF Then
            .MoveNext
            ViewRecord
         End If
    End With

End Sub

Private Sub CmdCreaRs_Click()

    Set AdoRs = New Recordset
    
     If AdoCnn.State = adStateClosed Then
        AdoCnn.Open
     End If
    
    With AdoRs
         .CursorLocation = adUseClient
         .CursorType = adOpenStatic
         .LockType = adLockBatchOptimistic
         .ActiveConnection = AdoCnn
         .Open STRSQL
         .ActiveConnection = Nothing
         Frame.Visible = True
         ViewRecord
    End With
    
    AdoCnn.Close

End Sub

Private Sub CmdIndietro_Click()

    With AdoRs
         If Not .BOF Then
            .MovePrevious
            ViewRecord
         End If
    End With
    

End Sub

Private Sub CmdSalva_Click()

    With AdoRs
         If Not .EOF And Not .BOF Then
            AdoRs.Fields(1).Value = TxtCompany.Text
         End If
    End With

 End Sub

Private Sub CmdSalvaServer_Click()

    Dim strErr As String

    'Salva su db server
    
    On Error GoTo ConflittoERR
    
    'Apre Connessione
    
    If AdoCnn.State = adStateClosed Then
       AdoCnn.Open
    End If
    
    'Update
    
    With AdoRs
         .ActiveConnection = AdoCnn
         .UpdateBatch
         Set .ActiveConnection = Nothing
    End With
    
    
    AdoCnn.Close
    
    Exit Sub
         
    
ConflittoERR:

'Verifico se ci sono confliti
        
    With AdoRs
         .Filter = adFilterConflictingRecords
         
         Do While Not .EOF
            strErr = "Record " & .Fields(1).Value & vbCrLf
            
            Select Case .State
                   Case adRecCanceled
                   
                        strErr = strErr & "Record Cancellato" & vbCrLf

                   Case adRecCantRelease
                   
                        strErr = strErr & "Record Locked" & vbCrLf

                   Case adRecDeleted
                   
                        strErr = strErr & "Cancellato" & vbCrLf

                   Case adRecConcurrencyViolation
                   
                        strErr = strErr & "Modificato" & vbCrLf
                 
                        
                   Case Else
                        strErr = strErr & "Modificato" & vbCrLf

            End Select
            
            
            
            strErr = strErr & "Valore prima " & .Fields(1).OriginalValue & vbCrLf
          
            strErr = strErr & "Valore modificato " & .Fields(1).Value & vbCrLf
            
            .Resync
            
            strErr = strErr & "Valore ora " & .Fields(1).OriginalValue & vbCrLf
                        
            If MsgBox(strErr & vbCrLf & "Confermi tue modifiche ? ", vbInformation + vbYesNo, "Attenzione") = vbYes Then
               Resume
'            Else
'               Exit Do
            End If
            
            .MoveNext
                    
         Loop
    
    End With
    
    
    
    

End Sub

Private Sub Form_Load()

 Set AdoCnn = New Connection
 AdoCnn.ConnectionString = "Provider=SQLOLEDB.1;Password=test;Persist Security Info=True;User ID=test;Initial Catalog=Northwind;Data Source=NOONE2\SQL2000SP"
  

End Sub

Private Sub Form_Unload(Cancel As Integer)

    If AdoCnn.State = adStateOpen Then
       AdoCnn.Close
    End If
    
    Set AdoRs = Nothing
    Set AdoCnn = Nothing

End Sub

Private Sub ViewRecord()

    With AdoRs
         If Not .EOF And Not .BOF Then
            TtxId.Text = .Fields(0).Value
            TxtCompany.Text = .Fields(1).Value
         End If
    End With
             

End Sub
