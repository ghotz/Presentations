VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form FrmSp 
   Caption         =   "UgissSp"
   ClientHeight    =   6615
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8505
   LinkTopic       =   "Form1"
   ScaleHeight     =   6615
   ScaleWidth      =   8505
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton CmdSp5 
      Caption         =   "Chiamata a Stored Procedure (REFRESH PARAMETERS)"
      Height          =   375
      Left            =   120
      TabIndex        =   8
      Top             =   2520
      Width           =   4455
   End
   Begin VB.CommandButton CmdSp4 
      Caption         =   "Chiamata a Stored Procedure (NO COMMANDTYPE)"
      Height          =   375
      Left            =   120
      TabIndex        =   7
      Top             =   2040
      Width           =   4455
   End
   Begin VB.CommandButton CmdExec 
      Caption         =   "Exec"
      Height          =   375
      Left            =   4800
      TabIndex        =   6
      Top             =   1560
      Visible         =   0   'False
      Width           =   1335
   End
   Begin VB.CommandButton cmdSp3 
      Caption         =   "Prepared"
      CausesValidation=   0   'False
      Height          =   375
      Left            =   120
      TabIndex        =   5
      Top             =   1560
      Width           =   4455
   End
   Begin VB.CommandButton cmdSp2 
      Caption         =   "Chiamata a Stored Procedure (COMMAND)"
      Height          =   375
      Left            =   120
      TabIndex        =   4
      Top             =   1080
      Width           =   4455
   End
   Begin VB.ComboBox CboPar2 
      Height          =   315
      ItemData        =   "FrmSp.frx":0000
      Left            =   2640
      List            =   "FrmSp.frx":0043
      Style           =   2  'Dropdown List
      TabIndex        =   3
      Top             =   120
      Width           =   2415
   End
   Begin VB.ComboBox cboPar1 
      Height          =   315
      ItemData        =   "FrmSp.frx":00F9
      Left            =   120
      List            =   "FrmSp.frx":013C
      Style           =   2  'Dropdown List
      TabIndex        =   2
      Top             =   120
      Width           =   2415
   End
   Begin MSHierarchicalFlexGridLib.MSHFlexGrid MSFlexGrid 
      Height          =   3135
      Left            =   120
      TabIndex        =   1
      Top             =   3000
      Width           =   8175
      _ExtentX        =   14420
      _ExtentY        =   5530
      _Version        =   393216
      FixedCols       =   0
      AllowUserResizing=   1
      _NumberOfBands  =   1
      _Band(0).Cols   =   2
      _Band(0).GridLinesBand=   1
      _Band(0).TextStyleBand=   0
      _Band(0).TextStyleHeader=   0
   End
   Begin VB.CommandButton CmdSp1 
      Caption         =   "Chiamata a Stored Procedure (NO COMMAND)"
      Height          =   375
      Left            =   120
      TabIndex        =   0
      Top             =   600
      Width           =   4455
   End
End
Attribute VB_Name = "FrmSp"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim AdoCnn As Connection
Dim AdoRs  As Recordset
Dim AdoCmd As Command
Dim strSql As String

Private Sub CmdExec_Click()


   Screen.MousePointer = vbHourglass

     
   AdoCnn.Open
   
   
   
   With AdoCmd
            .ActiveConnection = AdoCnn
            .Parameters(0).Value = cboPar1.Text
            .Parameters(1).Value = CboPar2.Text
             Set AdoRs = .Execute
            Set MSFlexGrid.DataSource = AdoRs
   End With
   
   
   AdoCnn.Close
   
   Set AdoRs = Nothing
   
   Screen.MousePointer = vbNormal
   

End Sub

Private Sub CmdSp1_Click()

   Screen.MousePointer = vbHourglass
   
   CmdExec.Visible = False

   strSql = "dbo.spTest '" & cboPar1.Text & "'" & ", '" & CboPar2.Text & " '"
      
   AdoCnn.Open
   
   
   
   Set AdoRs = AdoCnn.Execute(strSql)
   
   
   Set MSFlexGrid.DataSource = AdoRs
   
   
   AdoCnn.Close
   
   Set AdoRs = Nothing
   
   Screen.MousePointer = vbNormal
    

End Sub

Private Sub cmdSp2_Click()

   Screen.MousePointer = vbHourglass
   
   CmdExec.Visible = False

   Set AdoCmd = New Command
   
   strSql = "dbo.spTest" ' '" & Text1.Text & "'" & ", '" & Text2.Text & " '"
      
   AdoCnn.Open
 
   
   With AdoCmd
        .ActiveConnection = AdoCnn
        .CommandType = adCmdStoredProc
        .CommandText = strSql
        .Parameters.Append .CreateParameter("RETURN_VALUE", adInteger, adParamReturnValue)
        .Parameters.Append .CreateParameter("Country1", adWChar, adParamInput, 15, cboPar1.Text)
        .Parameters.Append .CreateParameter("Country2", adWChar, adParamInput, 15, CboPar2.Text)
        Set AdoRs = .Execute
   End With
   
   Set MSFlexGrid.DataSource = AdoRs
   
   AdoCnn.Close
   
   Set AdoCmd = Nothing
   
   Screen.MousePointer = vbNormal

End Sub

Private Sub cmdSp3_Click()

   Screen.MousePointer = vbHourglass
   
   CmdExec.Visible = True

   Set AdoCmd = New Command
   
   strSql = "select CompanyName ,country,ContactName " & _
            " From customers Where country = ? " & _
            " or country = ? "
      
   AdoCnn.Open
 
   
   With AdoCmd
        .ActiveConnection = AdoCnn
        .Prepared = True
        .CommandType = adCmdText
        .CommandText = strSql
        .Parameters.Append .CreateParameter("Country1", adWChar, adParamInput, 15, cboPar1.Text)
        .Parameters.Append .CreateParameter("Country2", adWChar, adParamInput, 15, CboPar2.Text)
    End With
   
   AdoCmd(0) = cboPar1.Text
   AdoCmd(1) = CboPar2.Text
   Set AdoRs = AdoCmd.Execute
   
   Set MSFlexGrid.DataSource = AdoRs
   
   AdoCnn.Close
   
      
   Screen.MousePointer = vbNormal
   
End Sub

Private Sub Command1_Click()

End Sub

Private Sub CmdSp4_Click()

   Screen.MousePointer = vbHourglass
   
   CmdExec.Visible = False

   Set AdoCmd = New Command
   
   strSql = "dbo.spTest" ' '" & Text1.Text & "'" & ", '" & Text2.Text & " '"
      
   AdoCnn.Open
 
   
   With AdoCmd
        .ActiveConnection = AdoCnn
        .CommandType = adCmdUnknown
        .CommandText = strSql
        .Parameters.Append .CreateParameter("RETURN_VALUE", adInteger, adParamReturnValue)
        .Parameters.Append .CreateParameter("Country1", adWChar, adParamInput, 15, cboPar1.Text)
        .Parameters.Append .CreateParameter("Country2", adWChar, adParamInput, 15, CboPar2.Text)
        Set AdoRs = .Execute
   End With
   
   Set MSFlexGrid.DataSource = AdoRs
   
   AdoCnn.Close
   
   Set AdoCmd = Nothing
   
   Screen.MousePointer = vbNormal
End Sub

Private Sub CmdSp5_Click()

 Screen.MousePointer = vbHourglass
   
   CmdExec.Visible = False

   Set AdoCmd = New Command
   
   strSql = "dbo.spTest" ' '" & Text1.Text & "'" & ", '" & Text2.Text & " '"
      
   AdoCnn.Open
 
   
   With AdoCmd
        .ActiveConnection = AdoCnn
        .CommandType = adCmdStoredProc
        .CommandText = strSql
        .Parameters.Refresh
        .Parameters(1).Value = cboPar1
        .Parameters(2).Value = CboPar2
        Set AdoRs = .Execute
   End With
   
   Set MSFlexGrid.DataSource = AdoRs
   
   AdoCnn.Close
   
   Set AdoCmd = Nothing
   
   Screen.MousePointer = vbNormal

End Sub

Private Sub Form_Load()

  Set AdoCnn = New Connection
  AdoCnn.ConnectionString = "Provider=SQLOLEDB.1;Password=test;Persist Security Info=True;User ID=test;Initial Catalog=Northwind;Data Source=NOONE2\SQL2000SP"
  cboPar1.ListIndex = 0
  CboPar2.ListIndex = 0
  
End Sub

Private Sub Form_Unload(Cancel As Integer)

    Set AdoCnn = Nothing

End Sub

